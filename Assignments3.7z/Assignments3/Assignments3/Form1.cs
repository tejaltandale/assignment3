﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Assignments3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            comboBox1.Visible = true;
            comboBox2.Visible = false;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            comboBox2.Visible = true;
            comboBox1.Visible = false;
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
          
            comboBox1.Items.Add("IT");
            comboBox1.Items.Add("Admin");
            comboBox1.Items.Add("Facitilies");
            comboBox1.Items.Add("HR");

            comboBox2.Items.Add("Consultant");
            comboBox2.Items.Add("Sr.Consultant");
            comboBox2.Items.Add("Lead Consultant");
            comboBox2.Items.Add("Manager");
            comboBox2.Items.Add("Sr. Manager");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String combo_Selection="default";
            String radio_selection;

            bool isChecked = radioButton1.Checked;
            if (isChecked)
                radio_selection = radioButton1.Text;
            else
                radio_selection = radioButton2.Text;

            if (radio_selection == "Department Wise")
            {

                combo_Selection = comboBox1.SelectedItem.ToString();
            }
            else
            {
                combo_Selection = comboBox2.SelectedItem.ToString();

            }

           // MessageBox.Show(radio_selection+"    "+combo_Selection);

            ExcelFile source = ExcelFile.Load("Source.xlsx");
            ExcelColumn sourceColumn = source.Worksheets[0].Columns[0];

            ExcelFile destination = ExcelFile.Load("Destination.xlsx");
            ExcelColumn destinationColumn = destination.Worksheets[0].Columns[0];

            int count = source.Worksheets[0].Rows.Count;
            for (int i = 0; i < count; i++)
                destinationColumn.Cells[i].Value = sourceColumn.Cells[i].Value;

            destination.Save("Destination.xlsx");
        }
    }
     
}
